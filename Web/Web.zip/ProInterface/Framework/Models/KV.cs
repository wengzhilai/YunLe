﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProInterface.Models
{
    public class KV
    {
        /// <summary>
        /// 主键
        /// </summary>
        public string K { get; set; }

        /// <summary>
        /// 值
        /// </summary>
        public string V { get; set; }
    }
}
