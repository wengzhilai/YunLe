﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProInterface.Models
{
    public class YlGarage:YL_GARAGE
    {
        public string picIdUrl { get; set; }
        public string StartNum { get; set; }
        public string OrderNum { get; set; }
    }
}
