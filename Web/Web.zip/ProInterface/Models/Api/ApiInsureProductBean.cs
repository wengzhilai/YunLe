﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProInterface.Models.Api
{
    public class ApiInsureProductBean:YL_INSURER_PRODUCT
    {
        public decimal? Price { get; set; }
    }
}
