﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProInterface.Models
{
    public class YlCar:YL_CAR
    {
        public string DrivingPicUrl { get; set; }
        public string DrivingPicUrl1 { get; set; }
        public string idNoUrl { get; set; }
        public string idNoUrl1 { get; set; }
        public string billUrl { get; set; }
        public string certificatePicUrl { get; set; }
    }
}
